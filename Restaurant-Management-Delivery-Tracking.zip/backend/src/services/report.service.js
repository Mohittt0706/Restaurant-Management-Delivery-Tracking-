class ReportService {
  async getDailySalesReport() {
    return { totalOrders: 0, totalRevenue: 0 };
  }
}

module.exports = new ReportService();

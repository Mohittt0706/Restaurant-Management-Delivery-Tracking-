class MenuService {
  async getAllItems() {
    return [];
  }

  async getItemById(id) {
    return { id, name: 'Sample Item' };
  }
}

module.exports = new MenuService();

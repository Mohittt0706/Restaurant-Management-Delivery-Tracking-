class PaymentService {
  async processPayment(paymentData) {
    return { status: 'COMPLETED', transactionId: 'TXN_' + Date.now() };
  }
}

module.exports = new PaymentService();

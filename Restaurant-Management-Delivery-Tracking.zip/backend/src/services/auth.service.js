class AuthService {
  async register(userData) {
    return { id: 1, ...userData };
  }

  async login(credentials) {
    return { token: 'mock_jwt_token', user: { id: 1, email: credentials.email } };
  }
}

module.exports = new AuthService();

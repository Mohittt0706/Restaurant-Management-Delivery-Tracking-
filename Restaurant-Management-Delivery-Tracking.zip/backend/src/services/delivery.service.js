class DeliveryService {
  async getDeliveryDetails(orderId) {
    return { orderId, status: 'ASSIGNED' };
  }

  async updateLocation(driverId, lat, lng) {
    return { driverId, lat, lng };
  }
}

module.exports = new DeliveryService();

class InventoryService {
  async getInventoryList() {
    return [];
  }

  async updateStock(itemId, quantity) {
    return { itemId, quantity };
  }
}

module.exports = new InventoryService();

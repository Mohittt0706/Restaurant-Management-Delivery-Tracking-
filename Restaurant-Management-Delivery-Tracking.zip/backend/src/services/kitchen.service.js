class KitchenService {
  async getActiveOrders() {
    return [];
  }

  async updateKitchenStatus(orderId, status) {
    return { orderId, status };
  }
}

module.exports = new KitchenService();

class OrderService {
  async createOrder(orderData) {
    return { id: 1, ...orderData, status: 'PENDING' };
  }

  async getOrderById(id) {
    return { id, status: 'PENDING' };
  }
}

module.exports = new OrderService();

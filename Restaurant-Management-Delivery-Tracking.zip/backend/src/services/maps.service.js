class MapsService {
  async calculateRoute(origin, destination) {
    return { distanceKm: 4.5, estimatedMinutes: 18 };
  }
}

module.exports = new MapsService();

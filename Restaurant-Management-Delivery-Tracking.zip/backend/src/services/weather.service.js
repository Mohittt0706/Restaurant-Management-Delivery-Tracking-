class WeatherService {
  async getWeatherImpact(location) {
    return { condition: 'Clear', delayMultiplier: 1.0 };
  }
}

module.exports = new WeatherService();

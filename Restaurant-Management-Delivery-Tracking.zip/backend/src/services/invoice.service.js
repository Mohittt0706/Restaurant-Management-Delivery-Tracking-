class InvoiceService {
  async getInvoiceByOrderId(orderId) {
    return { orderId, invoiceNumber: 'INV-1001' };
  }
}

module.exports = new InvoiceService();

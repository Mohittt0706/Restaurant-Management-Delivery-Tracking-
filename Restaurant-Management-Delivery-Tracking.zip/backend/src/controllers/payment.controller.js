const paymentService = require('../services/payment.service');

const processPayment = async (req, res, next) => {
  try {
    const result = await paymentService.processPayment(req.body);
    res.status(200).json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
};

module.exports = { processPayment };

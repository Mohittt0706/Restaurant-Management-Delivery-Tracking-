const deliveryService = require('../services/delivery.service');

const getDeliveryDetails = async (req, res, next) => {
  try {
    const details = await deliveryService.getDeliveryDetails(req.params.orderId);
    res.status(200).json({ success: true, data: details });
  } catch (err) {
    next(err);
  }
};

module.exports = { getDeliveryDetails };

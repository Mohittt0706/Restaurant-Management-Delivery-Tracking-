const inventoryService = require('../services/inventory.service');

const getInventory = async (req, res, next) => {
  try {
    const list = await inventoryService.getInventoryList();
    res.status(200).json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
};

module.exports = { getInventory };

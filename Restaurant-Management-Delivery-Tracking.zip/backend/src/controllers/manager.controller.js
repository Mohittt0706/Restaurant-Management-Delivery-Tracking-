const getDashboardData = async (req, res, next) => {
  try {
    res.status(200).json({ success: true, message: 'Manager dashboard endpoint' });
  } catch (err) {
    next(err);
  }
};

module.exports = { getDashboardData };

const menuService = require('../services/menu.service');

const getMenuItems = async (req, res, next) => {
  try {
    const items = await menuService.getAllItems();
    res.status(200).json({ success: true, data: items });
  } catch (err) {
    next(err);
  }
};

module.exports = { getMenuItems };

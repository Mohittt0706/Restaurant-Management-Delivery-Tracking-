const kitchenService = require('../services/kitchen.service');

const getActiveOrders = async (req, res, next) => {
  try {
    const orders = await kitchenService.getActiveOrders();
    res.status(200).json({ success: true, data: orders });
  } catch (err) {
    next(err);
  }
};

module.exports = { getActiveOrders };

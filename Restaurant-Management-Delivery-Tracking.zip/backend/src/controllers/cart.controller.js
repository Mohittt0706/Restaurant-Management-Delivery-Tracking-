const getCart = async (req, res, next) => {
  try {
    res.status(200).json({ success: true, data: { items: [] } });
  } catch (err) {
    next(err);
  }
};

module.exports = { getCart };

const express = require('express');
const router = express.Router();
const deliveryController = require('../controllers/delivery.controller');

router.get('/:orderId', deliveryController.getDeliveryDetails);

module.exports = router;

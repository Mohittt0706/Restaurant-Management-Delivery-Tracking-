const express = require('express');
const router = express.Router();
const managerController = require('../controllers/manager.controller');

router.get('/dashboard', managerController.getDashboardData);

module.exports = router;

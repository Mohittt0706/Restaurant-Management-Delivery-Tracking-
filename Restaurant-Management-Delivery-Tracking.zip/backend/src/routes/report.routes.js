const express = require('express');
const router = express.Router();
const reportController = require('../controllers/report.controller');

router.get('/sales', reportController.getSalesReport);

module.exports = router;

const express = require('express');
const router = express.Router();
const kitchenController = require('../controllers/kitchen.controller');

router.get('/active', kitchenController.getActiveOrders);

module.exports = router;

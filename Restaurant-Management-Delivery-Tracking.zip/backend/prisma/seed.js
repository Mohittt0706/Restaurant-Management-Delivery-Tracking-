const prisma = require('../src/config/prisma');

async function main() {
  console.log('Seeding initial data...');
  // Seed implementation placeholder
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
